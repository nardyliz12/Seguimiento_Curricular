const express = require("express");
const router = express.Router();
const multer = require("multer");
const { parse } = require("csv-parse/sync");
const db = require("../db");

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

function courseExists(code) {
  return db.prepare(`SELECT code, credits FROM courses WHERE code = ?`).get(code);
}

function normalizeStatusFromGrade(grade) {
  if (grade === null || grade === undefined || grade === "") return "completed";
  const num = Number(grade);
  if (Number.isNaN(num)) return "completed";
  // Nota mínima aprobatoria típica UPCH: 10.5 / 11. Ajustable por el usuario en el frontend.
  return num >= 10.5 ? "completed" : "pending";
}

// POST /api/upload/csv  (multipart, campo "file")
// Formato esperado del CSV: codigo,nota,ciclo  (encabezados flexibles)
router.post("/csv", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No se recibió ningún archivo." });

  let records;
  try {
    records = parse(req.file.buffer.toString("utf-8"), {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });
  } catch (e) {
    return res.status(400).json({ error: "No se pudo leer el CSV. Verifica el formato.", detail: e.message });
  }

  const preview = [];
  for (const row of records) {
    const codigo = (row.codigo || row.code || row.Codigo || row.CODIGO || "").toString().trim().toUpperCase();
    const notaRaw = row.nota ?? row.grade ?? row.Nota ?? row.NOTA;
    const cicloRaw = row.ciclo ?? row.cycle ?? row.Ciclo ?? row.CICLO;

    if (!codigo) continue;
    const course = courseExists(codigo);
    const status = normalizeStatusFromGrade(notaRaw);

    preview.push({
      code: codigo,
      found: !!course,
      credits: course ? course.credits : null,
      grade: notaRaw !== undefined && notaRaw !== "" ? Number(notaRaw) : null,
      cycleTaken: cicloRaw ? Number(cicloRaw) : null,
      status,
    });
  }

  res.json({ ok: true, rows: preview.length, preview });
});

// POST /api/upload/pdf  (multipart, campo "file") — extracción best-effort de código+nota
router.post("/pdf", upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No se recibió ningún archivo." });

  let pdfParse;
  try {
    pdfParse = require("pdf-parse");
  } catch (e) {
    return res.status(500).json({ error: "pdf-parse no está instalado en el backend." });
  }

  let text;
  try {
    const data = await pdfParse(req.file.buffer);
    text = data.text;
  } catch (e) {
    return res.status(400).json({ error: "No se pudo leer el PDF.", detail: e.message });
  }

  // Heurística: busca líneas con un código tipo C0000/C0000 o letras+dígitos, seguido de una nota numérica (0-20)
  const lines = text.split(/\r?\n/);
  const codeRegex = /\b([A-Z]{2,4}\d{3,5})\b/;
  const gradeRegex = /(?<!\d)(20(?:\.0)?|1\d(?:\.\d{1,2})?|0?\d(?:\.\d{1,2})?)(?!\d)/;

  const preview = [];
  const unmatchedLines = [];

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    const codeMatch = line.match(codeRegex);
    if (!codeMatch) continue;

    const codigo = codeMatch[1].toUpperCase();
    const course = courseExists(codigo);
    if (!course) continue; // no forma parte de esta malla, se ignora

    // busca una nota en el resto de la línea (heurística, no perfecta)
    const rest = line.slice(codeMatch.index + codeMatch[0].length);
    const gradeMatch = rest.match(gradeRegex);
    const grade = gradeMatch ? Number(gradeMatch[1]) : null;

    preview.push({
      code: codigo,
      found: true,
      credits: course.credits,
      grade,
      cycleTaken: null,
      status: normalizeStatusFromGrade(grade),
      sourceLine: line.slice(0, 160),
    });
  }

  if (preview.length === 0) {
    unmatchedLines.push(...lines.filter((l) => l.trim()).slice(0, 15));
  }

  res.json({
    ok: true,
    warning:
      "La extracción desde PDF es aproximada (depende del formato de tu ficha). Revisa y corrige antes de confirmar. Si el resultado es pobre, usa la carga por CSV o edita manualmente.",
    rows: preview.length,
    preview,
    unmatchedSample: preview.length === 0 ? unmatchedLines : undefined,
  });
});

module.exports = router;
